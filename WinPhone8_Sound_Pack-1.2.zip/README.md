# WinPhone 8 SYSTEMLESS SOUNDS

**Attention!** Some sounds have to be set manually through settings such as your default alarm sound, default notifications sound, and Phone ringtone!

UI Sounds are replaced automatically.

Some alarm sounds/ringtones may appear repeated in the ringtone chooser, I think it depends on your rom.

Changelog 

07/08/20

- Add ring tone sounds

